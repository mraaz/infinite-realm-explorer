# lambda_function.py
# Main handler for the Infinite Life adaptive questionnaire.

import os
import json
import boto3
import jwt
from datetime import datetime, timezone

# --- Configuration ---
DYNAMODB_TABLE_NAME = os.environ.get('ANSWERS_TABLE_NAME', 'infinitelife-answers')
JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'a-very-secret-key')
SCORING_THRESHOLD = float(os.environ.get('SCORING_THRESHOLD', 0.80))

# --- AWS Service Clients ---
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(DYNAMODB_TABLE_NAME)

# --- Questions & Scoring Data ---
with open('questions.json', 'r') as f:
    QUESTIONS_CONFIG = json.load(f)

# --- Helper Functions ---

def get_user_from_jwt(event):
    """Decodes the JWT from the request headers to get the user ID."""
    try:
        auth_header = event.get('headers', {}).get('Authorization') or event.get('headers', {}).get('authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return None
        token = auth_header.split(' ')[1]
        decoded = jwt.decode(token, JWT_SECRET_KEY, algorithms=['HS256'])
        return decoded
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError, IndexError, KeyError):
        return None

def calculate_score(question, answer):
    """Calculates the score for a given answer based on the question type."""
    q_type = question['type']
    scoring = question['scoring']
    
    if q_type == 'slider':
        return (int(answer) / 10) * scoring['points']
    
    elif q_type == 'yes-no':
        return scoring['points'] if str(answer).lower() == scoring['target_answer'].lower() else 0

    elif q_type == 'multiple-choice':
        return scoring.get(str(answer), 0)
        
    return 0

def get_next_question_id(current_question_id):
    """Finds the ID of the next question in the predefined flow."""
    try:
        flow = QUESTIONS_CONFIG['question_flow']
        current_index = flow.index(current_question_id)
        if current_index + 1 < len(flow):
            return flow[current_index + 1]
        else:
            return None # End of questionnaire
    except (ValueError, IndexError):
        return None

def calculate_pillar_progress(user_state, questions_config):
    """
    Calculates the completion percentage for each main pillar based on user scores.
    """
    pillars = {
        "career": {"earned": 0, "possible": 0},
        "financials": {"earned": 0, "possible": 0},
        "health": {"earned": 0, "possible": 0},
        "connections": {"earned": 0, "possible": 0}
    }

    current_section_scores = user_state.get('section_scores', {})

    for section_id, section_data in questions_config.get('sections', {}).items():
        pillar_key = section_id.split('_')[0]

        if pillar_key in pillars:
            pillars[pillar_key]['possible'] += section_data.get('total_points', 0)
            pillars[pillar_key]['earned'] += current_section_scores.get(section_id, 0)

    pillar_percentages = {}
    for pillar_key, scores in pillars.items():
        if scores['possible'] > 0:
            percentage = (scores['earned'] / scores['possible']) * 100
            pillar_percentages[pillar_key] = round(percentage, 2)
        else:
            pillar_percentages[pillar_key] = 0
            
    return pillar_percentages

# --- Main Logic Handler ---

def handle_answer(event_body, user):
    """Processes a single answer submission."""
    question_id = event_body['questionId']
    answer = event_body['answer']

    question_data = QUESTIONS_CONFIG['questions'].get(question_id)
    if not question_data:
        return {'statusCode': 404, 'body': json.dumps({'error': 'Question not found'})}

    user_state = {'answers': {}, 'section_scores': {}, 'completed_sections': []}
    
    if user:
        try:
            response = table.get_item(Key={'userId': user['sub']})
            if 'Item' in response:
                user_state = response['Item']
        except Exception as e:
            print(f"Error fetching user state: {e}")

    user_state['answers'][question_id] = answer
    score = calculate_score(question_data, answer)
    
    section_id = question_data['section']
    section_config = QUESTIONS_CONFIG['sections'][section_id]
    
    user_state['section_scores'][section_id] = user_state['section_scores'].get(section_id, 0) + score
    
    next_question_id = get_next_question_id(question_id)
    
    if question_id in section_config.get('adaptive_trigger_questions', []):
        current_section_score = user_state['section_scores'][section_id]
        max_score_so_far = section_config['adaptive_max_score']
        
        if (current_section_score / max_score_so_far) >= SCORING_THRESHOLD:
            print(f"User scored high in section {section_id}. Skipping to next section.")
            user_state['completed_sections'].append(section_id)
            
            final_percentage = current_section_score / max_score_so_far
            user_state['section_scores'][section_id] = final_percentage * section_config['total_points']

            current_section_index = QUESTIONS_CONFIG['section_flow'].index(section_id)
            next_question_id = None
            for i in range(current_section_index + 1, len(QUESTIONS_CONFIG['section_flow'])):
                next_sec_id = QUESTIONS_CONFIG['section_flow'][i]
                next_question_id = QUESTIONS_CONFIG['sections'][next_sec_id]['questions'][0]
                break
    
    if user:
        user_state['userId'] = user['sub']
        user_state['lastQuestionId'] = next_question_id if next_question_id else 'completed'
        user_state['updatedAt'] = datetime.now(timezone.utc).isoformat()
        try:
            table.put_item(Item=user_state)
        except Exception as e:
            print(f"Error saving user state: {e}")

    # --- MODIFIED --- Call the progress calculation function
    progress = calculate_pillar_progress(user_state, QUESTIONS_CONFIG)

    if next_question_id:
        next_question_data = QUESTIONS_CONFIG['questions'][next_question_id]
        # --- MODIFIED --- Add pillarProgress to the response
        response_body = {'nextQuestion': next_question_data, 'pillarProgress': progress}
        return {'statusCode': 200, 'body': json.dumps(response_body)}
    else:
        # --- MODIFIED --- Add pillarProgress to the final response
        response_body = {'status': 'completed', 'finalScores': user_state['section_scores'], 'pillarProgress': progress}
        return {'statusCode': 200, 'body': json.dumps(response_body)}


def handle_save_progress(event_body, user):
    """Saves a guest's entire progress after they log in."""
    if not user:
        return {'statusCode': 401, 'body': json.dumps({'error': 'Authentication required'})}

    answers = event_body.get('answers', {})
    user_state = {
        'userId': user['sub'],
        'answers': answers,
        'section_scores': {},
        'completed_sections': [],
        'createdAt': datetime.now(timezone.utc).isoformat()
    }

    for q_id, ans in answers.items():
        question_data = QUESTIONS_CONFIG['questions'].get(q_id)
        if question_data:
            score = calculate_score(question_data, ans)
            section_id = question_data['section']
            user_state['section_scores'][section_id] = user_state['section_scores'].get(section_id, 0) + score

    last_Youtubeed = list(answers.keys())[-1]
    next_question_id = get_next_question_id(last_Youtubeed)
    user_state['lastQuestionId'] = next_question_id if next_question_id else 'completed'
    user_state['updatedAt'] = datetime.now(timezone.utc).isoformat()
    
    # --- MODIFIED --- Also calculate progress here
    progress = calculate_pillar_progress(user_state, QUESTIONS_CONFIG)
    user_state['pillarProgress'] = progress

    try:
        table.put_item(Item=user_state)
        # --- MODIFIED --- Return the full state instead of just a message for a smoother UX
        return {'statusCode': 200, 'body': json.dumps(user_state)}
    except Exception as e:
        print(f"Error saving progress: {e}")
        return {'statusCode': 500, 'body': json.dumps({'error': 'Could not save progress'})}


def handle_get_state(user):
    """Fetches the current state for a logged-in user."""
    if not user:
        return {'statusCode': 401, 'body': json.dumps({'error': 'Authentication required'})}

    try:
        response = table.get_item(Key={'userId': user['sub']})
        if 'Item' in response:
            user_state = response['Item']
            # --- MODIFIED --- Calculate progress for the returning user
            progress = calculate_pillar_progress(user_state, QUESTIONS_CONFIG)
            user_state['pillarProgress'] = progress
            return {'statusCode': 200, 'body': json.dumps(user_state)}
        else:
            # This is a new user, get their first question
            first_question_id = QUESTIONS_CONFIG['question_flow'][0]
            first_question = QUESTIONS_CONFIG['questions'][first_question_id]
            # --- MODIFIED --- Calculate initial progress (will be all zeros)
            initial_progress = calculate_pillar_progress({}, QUESTIONS_CONFIG)
            response_body = {'nextQuestion': first_question, 'pillarProgress': initial_progress}
            return {'statusCode': 200, 'body': json.dumps(response_body)}
    except Exception as e:
        print(f"Error getting state: {e}")
        return {'statusCode': 500, 'body': json.dumps({'error': 'Could not retrieve state'})}


# --- Lambda Entry Point ---
def lambda_handler(event, context):
    path = event.get('path')
    http_method = event.get('httpMethod', 'POST').upper() # Default to POST for safety
    user = get_user_from_jwt(event)
    
    try:
        body = json.loads(event.get('body', '{}'))
    except json.JSONDecodeError:
        return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid JSON body'})}

    if path == '/questionnaire/answer' and http_method == 'POST':
        return handle_answer(body, user)
    
    elif path == '/questionnaire/save-progress' and http_method == 'POST':
        return handle_save_progress(body, user)
        
    elif path == '/questionnaire/state' and http_method == 'GET':
        return handle_get_state(user)
        
    else:
        return {'statusCode': 404, 'body': json.dumps({'error': f'Endpoint not found or method {http_method} not allowed for {path}'})}


# --- Helper Functions ---

def calculate_pillar_progress(user_state, questions_config):
    """
    Calculates the completion percentage for each main pillar based on user scores.
    """
    # 1. Define the main pillars and initialize their score tracking.
    #    The keys ("career", "financials", etc.) must match the frontend component's expectations.
    pillars = {
        "career": {"earned": 0, "possible": 0},
        "financials": {"earned": 0, "possible": 0},
        "health": {"earned": 0, "possible": 0},
        "connections": {"earned": 0, "possible": 0}
    }

    # Get the user's current raw scores for each subsection.
    current_section_scores = user_state.get('section_scores', {})

    # 2. Loop through every section defined in the questions config.
    for section_id, section_data in questions_config.get('sections', {}).items():
        # This determines which main pillar a subsection belongs to.
        # e.g., "career_fulfillment" -> "career"
        # e.g., "health_fitness" -> "health"
        pillar_key = section_id.split('_')[0]

        if pillar_key in pillars:
            # Aggregate the total possible points for the pillar.
            pillars[pillar_key]['possible'] += section_data.get('total_points', 0)
            
            # Aggregate the points the user has actually earned for this pillar.
            # It's okay if the user hasn't started a section; .get(section_id, 0) handles that.
            pillars[pillar_key]['earned'] += current_section_scores.get(section_id, 0)

    # 3. Calculate the final percentages for each pillar.
    pillar_percentages = {}
    for pillar_key, scores in pillars.items():
        if scores['possible'] > 0:
            percentage = (scores['earned'] / scores['possible']) * 100
            # Round to 2 decimal places for a clean number.
            pillar_percentages[pillar_key] = round(percentage, 2)
        else:
            # If a pillar has no questions/points defined yet, its progress is 0.
            pillar_percentages[pillar_key] = 0
            
    return pillar_percentages
